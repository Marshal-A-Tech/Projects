export class Leave {
    empId:number;
    leavetype:string;
    startdate:string;
    enddate:string;
    duration:string;
}
